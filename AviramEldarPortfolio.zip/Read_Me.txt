The font: Asistanse
The Colors: https://coolors.co/151515-204883-119da4-e2ebf3-fff7eb
