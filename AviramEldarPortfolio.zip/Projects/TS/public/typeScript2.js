"use strict";
//crypto website
