# step 18 - Hide or show the buttons of the slider
auto run and stop run

# step 19 - Refactor the code 
move the buttons elements to a variable

# step 20 - add active class to pressed link

# step 21 - remove active class from previous currentActiveLink 

# step 22 - add baseUrl variable to image path

# step 23 - add flex classes for alignment of the page

# step 24 - butify buttons and add icons

# step 25 - add javascript object with description credits and more
# step 25 - add image description, credits and featured to the page
# step 26 - run renderImage at loading of the project to insert to first picture
# step 27 - change how mouseEnter and mouseLeave work
- When the slide is not running mouseEnter and mouseLeave does not effect the slide show
- When the slide is run mouseEnter and mouseLeave stop and run the slide show
- The buttons don't change
